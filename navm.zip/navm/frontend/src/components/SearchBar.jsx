import React, { useState } from "react";
import {
  Box,
  Input,
  Button,
  IconButton,
  HStack,
  useDisclosure,
  Divider,
  useColorModeValue,
} from "@chakra-ui/react";
import {
  FaSearch,
  FaMapMarkerAlt,
  FaCalendarAlt,
  FaUserFriends,
} from "react-icons/fa";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const SearchBar = () => {
  const [dates, setDates] = useState([null, null]);
  const { isOpen, onToggle } = useDisclosure();

  const formatDateRange = () => {
    const [startDate, endDate] = dates;
    if (!startDate || !endDate) return "Dates";
    return `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`;
  };

  return (
    <Box
      p={4}
      bg={useColorModeValue("white", "#1C1F37")}
      borderRadius="full"
      boxShadow="md"
      maxW="container.md"
      mx="auto"
      mt={10}
    >
      <HStack spacing={0} height="100%" align="center">
        {/* Location Input */}
        <HStack spacing={0} position="relative" flex="1" align="center">
          <Input
            variant="unstyled"
            placeholder="Choose Destination"
            pl={12}
            color={useColorModeValue("gray.600", "white")}
            sx={{
              "::placeholder": {
                color: useColorModeValue("#0B6B78", "white"), // Adjust the color values as needed
              },
            }}
          />
          <IconButton
            icon={<FaMapMarkerAlt />}
            aria-label="Location"
            variant="ghost"
            isRound
            position="absolute"
            size="lg" // Adjust size if necessary
            color={useColorModeValue("#0B6B78", "#D1F366")}
          />
        </HStack>

        <Divider
          orientation="vertical"
          height="40px"
          borderColor={useColorModeValue("gray.200", "gray.600")}
        />

        {/* Date Range Picker */}
        <HStack spacing={0} position="relative" flex="1">
          <Input
            variant="unstyled"
            placeholder="Dates"
            pl={12}
            value={formatDateRange()}
            readOnly
            color={useColorModeValue("#0B6B78", "white")}
            onClick={onToggle}
          />
          <IconButton
            icon={<FaCalendarAlt />}
            aria-label="Dates"
            variant="ghost"
            isRound
            size="lg"
            position="absolute"
            color={useColorModeValue("#0B6B78", "#D1F366")}
            onClick={onToggle}
          />
          {isOpen && (
            <Box position="absolute" zIndex="popover" left={0} top="100%">
              <DatePicker
                selectsRange={true}
                startDate={dates[0]}
                endDate={dates[1]}
                onChange={(update) => setDates(update)}
                inline
              />
            </Box>
          )}
        </HStack>

        <Divider
          orientation="vertical"
          height="40px"
          borderColor={useColorModeValue("gray.200", "gray.600")}
        />

        {/* Guests Input */}
        <HStack spacing={0} position="relative" flex="1">
          <Input
            variant="unstyled"
            placeholder="Number of travelers"
            pl={12}
            color={useColorModeValue("gray.600", "white")}
            sx={{
              "::placeholder": {
                color: useColorModeValue("#0B6B78", "white"), // Adjust the color values as needed
              },
            }}
          />
          <IconButton
            icon={<FaUserFriends />}
            aria-label="Guests"
            variant="ghost"
            isRound
            size="lg"
            position="absolute"
            color={useColorModeValue("#0B6B78", "#D1F366")}
          />
        </HStack>

        <Button
          colorScheme="teal"
          px={5}
          borderRadius="full"
          bg={useColorModeValue("#0B6B78", "#D1F366")}
          color={useColorModeValue("white", "gray.800")}
          _hover={{
            bg: useColorModeValue("#0B6B78", "#D1F366"),
          }}
          onClick={() => alert("Search functionality to be implemented")}
        >
          <FaSearch color={useColorModeValue("white", "#141627")} />
        </Button>
      </HStack>
    </Box>
  );
};

export default SearchBar;
